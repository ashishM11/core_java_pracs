package com.testapp.pdf.exp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.Base64;
import java.util.zip.GZIPInputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TestServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		 PrintWriter out = response.getWriter();
		response.setHeader("Content-disposition", "inline; filename='abc.pdf'");
		response.setContentType("application/pdf;charset=UTF-8");

		String file_loc = request.getParameter("loc").trim();
		String new_loc = request.getParameter("new_loc").trim();
		performGZipDecompress(file_loc, new_loc);
		byte[] encode = Base64.getEncoder().encode(Files.readAllBytes(new File(new_loc).toPath()));
		 for (int i = 0; i < encode.length; i++) {
             out.write((char) encode[i]);
         }
	}

	private void performGZipDecompress(String file_loc, String new_file_loc) {
		try {

			FileInputStream fis = new FileInputStream(new File(file_loc));
			GZIPInputStream gis = new GZIPInputStream(fis);

			FileOutputStream fos = new FileOutputStream(new_file_loc);
			byte[] buffer = new byte[1024];
			int len;
			while ((len = gis.read(buffer)) != -1) {
				fos.write(buffer, 0, len);
			}
			fos.close();
			gis.close();

		} catch (IOException objEx) {
			objEx.printStackTrace();
		}
	}

}
